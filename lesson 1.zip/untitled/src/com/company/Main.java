package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        String GreatDay;
        int NUM;
        NUM = 25;
        String word = "I am happy";
        GreatDay = ( NUM  + word );
        System.out.println(GreatDay);

        int number;
        number = 12;
        if (number > 0);{
            System.out.println("Вы сохранили положительное число");
        }if (number < 0);{
            System.out.println("Вы сохранили отрицательное число");
        }if (number = 0); {
            System.out.println("Вы сохранили нуль");
        }


    }
}
